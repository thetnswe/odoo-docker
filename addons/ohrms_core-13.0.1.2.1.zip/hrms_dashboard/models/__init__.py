# -*- coding: utf-8 -*-

from . import hrms_dashboard
