# -*- coding: utf-8 -*-
from . import hr_resignation
